import sqlite3

def create_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Criação da tabela de usuários
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    ''')

    # Cria uma tabela de comentários se não existir
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            comment TEXT NOT NULL
        )
    ''')

    
    # Inserção de usuários
    cursor.execute('''
    INSERT OR IGNORE INTO users (email, password) VALUES
    ('user1@example.com', 'password1'),
    ('user2@example.com', 'password2'),
    ('user3@example.com', 'password3')
    ''')
    
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_db()
    print("Banco de dados e usuários criados com sucesso!")
