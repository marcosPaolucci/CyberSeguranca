from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def validate_user(email, password):
    # Implementar a lógica de validação do usuário
    return True

# Página de login
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if validate_user(email, password):
            return redirect(url_for('news'))
        else:
            return "Credenciais inválidas", 401
    return render_template('login.html')

# Rota para exibir a página de notícias com comentários
@app.route('/noticias')
def news():
    # Conectar ao banco de dados e buscar os comentários
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('SELECT comment FROM comments')
    comments = cursor.fetchall()
    conn.close()
    
    # Passar os comentários para o template
    return render_template('noticia.html', comments=comments)

# Rota para processar o envio de comentários
@app.route('/submit-comment', methods=['POST'])
def submit_comment():
    # Obtém o comentário do formulário
    comment = request.form.get('comment')
    
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO comments (comment) VALUES (?)', (comment,))
    conn.commit()
    conn.close()
    
    # Redireciona de volta para a página de notícias
    return redirect(url_for('news'))

if __name__ == '__main__':
    app.run(debug=True)
